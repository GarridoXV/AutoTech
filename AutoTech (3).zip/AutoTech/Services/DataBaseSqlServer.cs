﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace AutoTech.Services {
    public class DataBaseSqlServer {
        // Método privado que cria nova conexão com o banco
   
        private SqlConnection CriarConexao() {
            return new SqlConnection("Data Source=localhost;Initial Catalog=AutoTech;Integrated Security=True;");
        }

        // Variável privada que armazena os parâmetros
        // que serão utilizados no comando SQL
        private SqlParameterCollection sqlParameterCollection = new SqlCommand().Parameters;

        // Método Público que limpa todos os parâmetros
        public void LimparParametros() {
            sqlParameterCollection.Clear();
        }

        // Método público para adicionar os novos parâmetros
        public void AdicionarParametros(string nomeParametro, object valorParametro) {
            sqlParameterCollection.Add(new SqlParameter(nomeParametro, valorParametro));
        }

        // Método público que executa comandos INSERT, UPDATE e DELETE
        public int ExecutarManipulacao(CommandType commandType, string query) {
            using (SqlConnection conexao = CriarConexao()) {
                using (SqlCommand comando = new SqlCommand(query, conexao)) {
                    comando.CommandType = commandType;
                    foreach (SqlParameter parametro in sqlParameterCollection) {
                        comando.Parameters.Add(parametro);
                    }
                    conexao.Open();
                    int resultado = comando.ExecuteNonQuery();
                    conexao.Close();
                    return resultado;
                }
            }
        }

        // Método público que executa comando SELECT e retorna a primeira coluna da primeira linha
        public object ExecutarConsultaScalar(CommandType commandType, string query) {
            using (SqlConnection conexao = CriarConexao()) {
                using (SqlCommand comando = new SqlCommand(query, conexao)) {
                    comando.CommandType = commandType;
                    foreach (SqlParameter parametro in sqlParameterCollection) {
                        comando.Parameters.Add(parametro);
                    }
                    conexao.Open();
                    object resultado = comando.ExecuteScalar();
                    conexao.Close();
                    return resultado;
                }
            }
        }
    }
}
