Create Database AutoTechFinal;

Use AutoTechFinal

-- Cria��o da tabela Clientes
CREATE TABLE Clientes (
    IdCliente INT PRIMARY KEY IDENTITY,
    Nome NVARCHAR(100),
    CPF NVARCHAR(20),
    DtNascimento DATE,
    Telefone NVARCHAR(20),
    Email NVARCHAR(100),
    Endereco NVARCHAR(200),
    Cidade NVARCHAR(100),
    Estado NVARCHAR(100),
    CEP NVARCHAR(20),
	Sexo CHAR(1),
    DataCadastro DATETIME
);

-- Cria��o da tabela Veiculos
CREATE TABLE Veiculos (
    IdVeiculo INT PRIMARY KEY,
    Marca NVARCHAR(50),
    Modelo NVARCHAR(50),
    Ano INT,
    Placa NVARCHAR(20),
    IdCliente INT,
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente)
);

-- Cria��o da tabela Funcionarios
CREATE TABLE Funcionarios (
    IdFuncionario INT PRIMARY KEY,
    Nome NVARCHAR(100),
    Cargo NVARCHAR(50),
    Telefone NVARCHAR(20),
    Email NVARCHAR(100)
);

-- Cria��o da tabela Servicos
CREATE TABLE Servicos (
    IdServico INT PRIMARY KEY,
    Descricao NVARCHAR(200),
    Preco DECIMAL(10, 2),
    DataInicio DATETIME,
    DataFim DATETIME,
    Status NVARCHAR(50),
    IdCliente INT,
    IdVeiculo INT,
    IdFuncionario INT,
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente),
    FOREIGN KEY (IdVeiculo) REFERENCES Veiculos(IdVeiculo),
    FOREIGN KEY (IdFuncionario) REFERENCES Funcionarios(IdFuncionario)
);

-- Cria��o da tabela Fornecedores
CREATE TABLE Fornecedores (
    IdFornecedor INT PRIMARY KEY,
    Nome NVARCHAR(100),
    Telefone NVARCHAR(20),
    Email NVARCHAR(100),
    Endereco NVARCHAR(200)
);

-- Cria��o da tabela Estoque
CREATE TABLE Estoque (
    IdPeca INT PRIMARY KEY,
    Descricao NVARCHAR(200),
    Quantidade INT,
    Preco DECIMAL(10, 2),
    IdFornecedor INT,
    FOREIGN KEY (IdFornecedor) REFERENCES Fornecedores(IdFornecedor)
);

-- Cria��o da tabela Agendamentos
CREATE TABLE Agendamentos (
    IdAgendamento INT PRIMARY KEY,
    DataHora DATETIME,
    IdCliente INT,
    IdServico INT,
    Observacoes NVARCHAR(200),
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente),
    FOREIGN KEY (IdServico) REFERENCES Servicos(IdServico)
);

-- Cria��o da tabela Faturamento
CREATE TABLE Faturamento (
    IdFatura INT PRIMARY KEY,
    Data DATETIME,
    ValorTotal DECIMAL(10, 2),
    StatusPagamento NVARCHAR(50),
    IdCliente INT,
    IdServico INT,
    FOREIGN KEY (IdCliente) REFERENCES Clientes(IdCliente),
    FOREIGN KEY (IdServico) REFERENCES Servicos(IdServico)
);


select * from Clientes;
