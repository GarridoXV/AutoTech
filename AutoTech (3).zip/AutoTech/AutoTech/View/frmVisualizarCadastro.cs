﻿using AutoTech.Controllers;
using AutoTech.Models;
using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using AutoTech.Services;

namespace AutoTech.View {
    public partial class frmVisualizarCadastro : Form {
        public Cliente clienteSelecao; // Para armazenar o cliente selecionado

        public frmVisualizarCadastro() {
            InitializeComponent();
            dgvRegistros.AutoGenerateColumns = false;
            // Configuração adicional, se necessário
        }

        public frmVisualizarCadastro(AcaoNaTela acaoTela) {
            InitializeComponent();
            dgvRegistros.AutoGenerateColumns = false;
            // Lógica adicional baseada na ação fornecida
        }

        private void Pesquisar() {
            int id = 0;
            ClienteController clienteController = new ClienteController();
            ClienteCollection clienteCollection = new ClienteCollection();
            dgvRegistros.DataSource = null;

            if (int.TryParse(txtPesquisa.Text, out id)) {
                Cliente cliente = clienteController.ConsultarPorId(id);
                if (cliente != null) {
                    clienteCollection.Add(cliente);
                }
            } else {
                clienteCollection = clienteController.ConsultarPorNome(txtPesquisa.Text);
            }

            dgvRegistros.DataSource = clienteCollection;
            dgvRegistros.Update();
            dgvRegistros.Refresh();
        }

        private void btnPesquisar_Click(object sender, EventArgs e) {
            Pesquisar();
        }

        private void btnExcluir_Click(object sender, EventArgs e) {
            Excluir();
        }

        private void Excluir() {
            if (dgvRegistros.SelectedRows.Count == 0) {
                MessageBox.Show("Nenhum registro selecionado.", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } else {
                if (MessageBox.Show("Deseja realmente excluir o registro?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes) {
                    Cliente clienteSelecionado = (Cliente)dgvRegistros.SelectedRows[0].DataBoundItem;
                    ClienteController clienteController = new ClienteController();

                    if (clienteController.ApagarCliente(clienteSelecionado.IdCliente) > 0) {
                        MessageBox.Show("Registro excluído com sucesso.", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Pesquisar();
                    } else {
                        MessageBox.Show("Não foi possível excluir o registro.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void frmVisualizarCadastro_Load(object sender, EventArgs e) {
            Pesquisar();
        }

        private void btnCadastrar_Click(object sender, EventArgs e) {
            ChamarTelaCadastro(AcaoNaTela.Inserir);
        }

        private void btnAlterar_Click(object sender, EventArgs e) {
            ChamarTelaCadastro(AcaoNaTela.Alterar);
        }

        private void ChamarTelaCadastro(AcaoNaTela acaoTela) {
            frmVisualizarCadastro frm = new frmVisualizarCadastro(acaoTela);
            frm.ShowDialog();
        }

        private void btnVisualizar_Click(object sender, EventArgs e) {
            ChamarTelaCadastro(AcaoNaTela.Visualizar);
        }

        private void dgvRegistros_CellContentClick(object sender, DataGridViewCellEventArgs e) {
            // Implementação conforme necessário
        }

        private void btnSelecionar_Click(object sender, EventArgs e) {
            clienteSelecao = RecuperarCliente();
            if (clienteSelecao != null) {
                this.DialogResult = DialogResult.OK;
            }
        }

        // Este método recupera o objeto cliente da linha selecionada na DataGridView
        private Cliente RecuperarCliente() {
            if (dgvRegistros.SelectedRows.Count > 0) {
                return dgvRegistros.SelectedRows[0].DataBoundItem as Cliente;
            }
            return null;
        }
    }
}
