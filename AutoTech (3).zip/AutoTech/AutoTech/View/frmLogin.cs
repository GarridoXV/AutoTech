﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoTech.View {
    public partial class frmLogin : Form {
        public frmLogin() {
            InitializeComponent();
        }

        private void btnEntrar_Click(object sender, EventArgs e) {
            // Obter o nome de usuário e senha inseridos pelo usuário
            string username = txtUsuario.Text.Trim();
            string password = txtSenha.Text.Trim();

            // Verificar se os campos estão vazios
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password)) {
                MessageBox.Show("Por favor, insira o nome de usuário e senha.", "Campos vazios", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Verificar se o nome de usuário e senha correspondem a "admin" e "admin123"
            if (username == "admin" && password == "admin123") {
                MessageBox.Show("Login bem-sucedido!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Criar e mostrar o frmPrincipal
                frmPrincipal principalForm = new frmPrincipal();
                principalForm.Show();

                // Esconder o formulário de login
                this.Hide();

            } else {
                MessageBox.Show("Nome de usuário ou senha incorretos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtUsuario_KeyPress(object sender, KeyPressEventArgs e) {

        }
    }
}

