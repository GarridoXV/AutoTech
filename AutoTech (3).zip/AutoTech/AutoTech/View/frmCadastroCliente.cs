﻿using System;
using System.Diagnostics;
using System.Windows.Forms;
using AutoTech.Models;
using AutoTech.Controllers;
using System.Data.SqlClient;

namespace AutoTech.View {
    public partial class frmCadastroCliente : Form {
        public frmCadastroCliente() {
            InitializeComponent();
            this.btnSalvar.Click += new EventHandler(this.btnSalvar_Click);
            this.Masculino.CheckedChanged += new EventHandler(this.Genero_CheckedChanged);
            this.Feminino.CheckedChanged += new EventHandler(this.Genero_CheckedChanged);
        }

        private void btnSalvar_Click(object sender, EventArgs e) {
            Cliente novoCliente = new Cliente {
                Nome = txtNome.Text,
                CPF = textCPF.Text,
                DtNascimento = dtpNascimento.Value,
                Telefone = txtTelefone.Text,
                Email = txtEmail.Text,
                Cidade = cbCidade.Text,
                Estado = cbEstado.Text,
                CEP = txtCEP.Text,
                Sexo = ObterCodigoSexo()
            };

            ClienteController clienteController = new ClienteController();
            try {
                int resultado = clienteController.InserirCliente(novoCliente);
                if (resultado > 0) {
                    Debug.WriteLine("Cliente inserido com sucesso!");
                    MessageBox.Show("Cliente inserido com sucesso!");
                } else {
                    Debug.WriteLine("Erro ao inserir o cliente.");
                    MessageBox.Show("Erro ao inserir o cliente.");
                }
            } catch (Exception ex) {
                Debug.WriteLine("Erro ao salvar o cliente: " + ex.Message);
                MessageBox.Show("Erro ao salvar o cliente: " + ex.Message);
            }
        }

        private void textCPF_MaskInputRejected(object sender, MaskInputRejectedEventArgs e) {
            // Lógica para quando a entrada do CPF for rejeitada, se necessário
        }

        private void textCPF_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Return) {
                bool valido = ValidarCPF(textCPF.Text);
                Debug.WriteLine(valido ? "CPF válido." : "CPF inválido.");
                MessageBox.Show(valido ? "CPF válido." : "CPF inválido.");
            }
        }

        public static bool ValidarCPF(string cpf) {
            cpf = cpf.Trim().Replace(".", "").Replace("-", "");

            if (cpf.Length != 11)
                return false;

            for (int i = 0; i < 10; i++)
                if (new string(cpf[0], 11) == cpf)
                    return false;

            var multiplicador1 = new int[] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            var multiplicador2 = new int[] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            string tempCpf = cpf.Substring(0, 9);
            int soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];

            int resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;

            string digito = resto.ToString();
            tempCpf += digito;
            soma = 0;

            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

            resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;

            digito += resto.ToString();

            return cpf.EndsWith(digito);
        }

        private void button1_Click(object sender, EventArgs e) {
            string connectionString = "Data Source=localhost;Initial Catalog=AutoTechFinal;Integrated Security=True;";

            try {
                using (SqlConnection conn = new SqlConnection(connectionString)) {
                    conn.Open();
                    MessageBox.Show("Conexão com o banco de dados bem-sucedida!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            } catch (Exception ex) {
                MessageBox.Show("Falha ao conectar com o banco de dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private char ObterCodigoSexo() {
            if (Masculino.Checked) {
                return 'M';
            } else if (Feminino.Checked) {
                return 'F';
            } else {
                
                return 'N';
            }
        }

        private void Genero_CheckedChanged(object sender, EventArgs e) {
            // Se precisar de alguma lógica adicional quando o estado dos botões de rádio mudar, adicione aqui
        }

     
    }
}
