﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoTech.View {
    public partial class frmPrincipal : Form {
        public frmPrincipal() {
            InitializeComponent();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e) {
            frmCadastroCliente frm = new frmCadastroCliente();
            frm.Show();
        }

        private void frmPrincipal_Load(object sender, EventArgs e) {

        }

        private void btnCliente_Click(object sender, EventArgs e) {
            frmVisualizarCadastro visualizarClienteForm = new frmVisualizarCadastro();
            visualizarClienteForm.Show();

        }
    }
}
