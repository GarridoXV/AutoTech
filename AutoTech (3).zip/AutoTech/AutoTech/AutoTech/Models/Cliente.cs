﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTech.Models {
    public class Cliente {
        public int IdCliente { get; set; }
        public string Nome { get; set; }
        public string CPF { get; set; }
        public DateTime DtNascimento { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string CEP { get; set; }
        public DateTime DataCadastro { get; set; }
        public char Sexo { get; set; }

        // Relações
        public List<Veiculo> Veiculos { get; set; }
        public List<Servico> Servicos { get; set; }
        public List<Agendamento> Agendamentos { get; set; }
        public List<Faturamento> Faturas { get; set; }
        
    }
}
