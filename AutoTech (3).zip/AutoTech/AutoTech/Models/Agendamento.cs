﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTech.Models {
    public class Agendamento {
        public int IdAgendamento { get; set; }
        public DateTime DataHora { get; set; }
        public int IdCliente { get; set; }
        public int IdServico { get; set; }
        public string Observacoes { get; set; }

       
    }
}
