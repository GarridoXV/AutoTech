﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoTech.Models {
    public class Faturamento {
        public int IdFatura { get; set; }
        public DateTime Data { get; set; }
        public decimal ValorTotal { get; set; }
        public string StatusPagamento { get; set; }
        public int IdCliente { get; set; }
        public int IdServico { get; set; }

   
    }
}
