﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace AutoTech.Services {
    public class DataBaseSqlServer {
        // Método privado que cria nova conexão com o banco
        private SqlConnection CriarConexao() {
            return new SqlConnection("Data Source=localhost;Initial Catalog=AutoTechFinal;Integrated Security=True;");
        }

        // Variável privada que armazena os parâmetros
        private SqlParameterCollection sqlParameterCollection = new SqlCommand().Parameters;

        // Método Público que limpa todos os parâmetros
        public void LimparParametros() {
            sqlParameterCollection.Clear();
        }

        // Método público para adicionar os novos parâmetros
        public void AdicionarParametros(string nomeParametro, object valorParametro) {
            sqlParameterCollection.Add(new SqlParameter(nomeParametro, valorParametro));
        }

        // Método público que executa comandos INSERT, UPDATE e DELETE
        public int ExecutarManipulacao(CommandType commandType, string query) {
            using (SqlConnection conexao = CriarConexao()) {
                using (SqlCommand comando = new SqlCommand(query, conexao)) {
                    comando.CommandType = commandType;
                    foreach (SqlParameter parametro in sqlParameterCollection) {
                        comando.Parameters.Add(new SqlParameter(parametro.ParameterName, parametro.Value));
                    }
                    conexao.Open();
                    int resultado = comando.ExecuteNonQuery();
                    conexao.Close();
                    LimparParametros(); // Limpa os parâmetros após a execução
                    return resultado;
                }
            }
        }

        // Método público que executa comando SELECT e retorna a primeira coluna da primeira linha
        public object ExecutarConsultaScalar(CommandType commandType, string query) {
            using (SqlConnection conexao = CriarConexao()) {
                using (SqlCommand comando = new SqlCommand(query, conexao)) {
                    comando.CommandType = commandType;
                    foreach (SqlParameter parametro in sqlParameterCollection) {
                        comando.Parameters.Add(new SqlParameter(parametro.ParameterName, parametro.Value));
                    }
                    conexao.Open();
                    object resultado = comando.ExecuteScalar();
                    conexao.Close();
                    LimparParametros(); // Limpa os parâmetros após a execução
                    return resultado;
                }
            }
        }

        public DataTable ExecutarConsulta(
    CommandType commandType,
    string nomeStoredProcedureOuTextpSql) {
            try {
                SqlConnection sqlConnection = CriarConexao();
                SqlCommand sqlCommand = sqlConnection.CreateCommand();

                sqlCommand.CommandType = commandType;
                sqlCommand.CommandText = nomeStoredProcedureOuTextpSql;

                foreach (SqlParameter sqlParameter
                    in sqlParameterCollection) {
                    sqlCommand.Parameters.Add(
                        new SqlParameter(sqlParameter.ParameterName,
                                            sqlParameter.Value));
                }

                //O C# precisa que o retorno do banco de dados serja 
                //convertido para um objeto. Para isso ele utiliza
                //o SqlDataAdapter, que irá "adaptar" p retorno
                //da consulta para um objeto do tipo DataTabel.
                //É o DataTable que será utlizado dentro do C#
                //Ou seja eu converto a tabela de dados sql
                //em tabale de dados C#
                SqlDataAdapter sqlDataAdapter =
                    new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();

                //Nesse ponto o comando SQL é executado
                //e o resultado é "adaptado" (convertido)
                //para o objeto dataTabela
                sqlDataAdapter.Fill(dataTable);

                return dataTable;
            } catch (Exception ex) {
                //Retorno o erro a onde o Método foi chamado
                throw new Exception("Houve uma falha ao execuar o " +
                    "comando no banco de dados.\r\n" +
                    "Mensagem original: " + ex.Message);
            }
        }
    }
}
