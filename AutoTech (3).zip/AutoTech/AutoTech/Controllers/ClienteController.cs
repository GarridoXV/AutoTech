﻿using AutoTech.Models;
using AutoTech.Services;
using System;
using System.Data;

namespace AutoTech.Controllers {
    public class ClienteController {
        private DataBaseSqlServer dataBase = new DataBaseSqlServer();

        public int InserirCliente(Cliente cliente) {
            string queryInserir =
                @"INSERT INTO Clientes 
                (Nome, CPF, DtNascimento, Telefone, Email, Cidade, Estado, CEP, DataCadastro, Sexo) 
                VALUES (@Nome, @CPF, @DtNascimento, @Telefone, @Email, @Cidade, @Estado, @CEP, GETDATE(), @Sexo)";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@Nome", cliente.Nome);
            dataBase.AdicionarParametros("@CPF", cliente.CPF);
            dataBase.AdicionarParametros("@DtNascimento", cliente.DtNascimento);
            dataBase.AdicionarParametros("@Telefone", cliente.Telefone);
            dataBase.AdicionarParametros("@Email", cliente.Email);
            dataBase.AdicionarParametros("@Cidade", cliente.Cidade);
            dataBase.AdicionarParametros("@Estado", cliente.Estado);
            dataBase.AdicionarParametros("@CEP", cliente.CEP);
            dataBase.AdicionarParametros("@Sexo", cliente.Sexo);

            dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);
            return Convert.ToInt32(dataBase.ExecutarConsultaScalar(CommandType.Text, "SELECT MAX(IdCliente) FROM clientes"));
        }

        public int AlterarCliente(Cliente cliente) {
            string queryAlterar =
                @"UPDATE Clientes SET 
                Nome = @Nome, CPF = @CPF, DtNascimento = @DtNascimento, Telefone = @Telefone, 
                Email = @Email, Cidade = @Cidade, Estado = @Estado, CEP = @CEP, Sexo = @Sexo 
                WHERE IdCliente = @IdCliente";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@IdCliente", cliente.IdCliente);
            dataBase.AdicionarParametros("@Nome", cliente.Nome);
            dataBase.AdicionarParametros("@CPF", cliente.CPF);
            dataBase.AdicionarParametros("@DtNascimento", cliente.DtNascimento);
            dataBase.AdicionarParametros("@Telefone", cliente.Telefone);
            dataBase.AdicionarParametros("@Email", cliente.Email);
            dataBase.AdicionarParametros("@Cidade", cliente.Cidade);
            dataBase.AdicionarParametros("@Estado", cliente.Estado);
            dataBase.AdicionarParametros("@CEP", cliente.CEP);
            dataBase.AdicionarParametros("@Sexo", cliente.Sexo);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryAlterar);
        }

        public int ApagarCliente(int idCliente) {
            string queryApagar =
                @"DELETE FROM Clientes WHERE IdCliente = @IdCliente";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@IdCliente", idCliente);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryApagar);
        }

        public ClienteCollection ConsultarPorNome(string nome) {
            ClienteCollection clienteColecao = new ClienteCollection();
            string query =
                "SELECT * FROM Cliente " +
                "WHERE Nome LIKE '%' + @Nome + '%'";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@Nome", nome.Trim());

            DataTable dataTable = dataBase.ExecutarConsulta(
                CommandType.Text, query);
            //Neste momento o SELECT foi executado 
            //E o banco retornou um DataTable
            //Agora precisamos converter esse DataTable
            //para ClienteCollection

            foreach (DataRow dataRow in dataTable.Rows) {
                Cliente cliente = new Cliente();
                //Agora vou indetificar o valor da linha na coluna
                //e atribuir ao objeto
                //Todo dado precisa ser convertido
                //do SQL Server para C#
                cliente.IdCliente = Convert.ToInt32(dataRow["IdCliente"]);
                cliente.Nome = Convert.ToString(dataRow["Nome"]);
                cliente.Email = Convert.ToString(dataRow["Email"]);
                cliente.CPF = Convert.ToString(dataRow["CPF"]);
                //Somente irei popular o atributo DtNascimento
                //Se o valor no banco de dados 
                //não estiver NULL
                if (!(dataRow["DtNascimento"] is DBNull))
                    cliente.DtNascimento =
                        Convert.ToDateTime(dataRow["DtNascimento"]);
                cliente.Telefone = Convert.ToString(dataRow["Telefone"]);

                //Adicione o objeto cliente na Coleção de Clientes
                //Ou seja cada linha retorna será um objeto
                //E a Collection tera um objeto de cada linha
                clienteColecao.Add(cliente);
            }
            return clienteColecao;
        }
        

        #region ConsultarPorId
        public Cliente ConsultarPorId(int IdCliente) {
            string query =
                "SELECT * FROM Cliente " +
                "WHERE IdCliente = @IdCliente";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@IdCliente", IdCliente);

            DataTable dataTable = dataBase.ExecutarConsulta(
                CommandType.Text, query);

            if (dataTable.Rows.Count > 0) {
                Cliente cliente = new Cliente();
                //Agora vou indetificar o valor da linha na coluna
                //e atribuir ao objeto
                //Todo dado precisa ser convertido
                //do SQL Server para C#
                cliente.IdCliente = Convert.ToInt32(dataTable.Rows[0]["IdCliente"]);
                cliente.Nome = Convert.ToString(dataTable.Rows[0]["Nome"]);
                cliente.Email = Convert.ToString(dataTable.Rows[0]["Email"]);
                cliente.CPF = Convert.ToString(dataTable.Rows[0]["CPF"]);
                //Somente irei popular o atributo DtNascimento
                //Se o valor no banco de dados 
                //não estiver NULL
                if (!(dataTable.Rows[0]["DtNascimento"] is DBNull))
                    cliente.DtNascimento =
                        Convert.ToDateTime(dataTable.Rows[0]["DtNascimento"]);
                cliente.Telefone = Convert.ToString(dataTable.Rows[0]["Telefone"]);

                //Adicione o objeto cliente na Coleção de Clientes
                //Ou seja cada linha retorna será um objeto
                //E a Collection tera um objeto de cada linha
                return cliente;
            } else
                return null;
        }
        #endregion
    }
}
