﻿using AutoTech.Models;
using AutoTech.Services;
using System;
using System.Data;

namespace AutoTech.Controllers {
    public class ClienteController {
        private DataBaseSqlServer dataBase = new DataBaseSqlServer();

        public int InserirCliente(Cliente cliente) {
            string queryInserir =
                @"INSERT INTO Clientes 
                (Nome, CPF, DtNascimento, Telefone, Email, Endereco, Cidade, Estado, CEP, DataCadastro) 
                VALUES (@Nome, @CPF, @DtNascimento, @Telefone, @Email, @Endereco, @Cidade, @Estado, @CEP, @DataCadastro)";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@Nome", cliente.Nome);
            dataBase.AdicionarParametros("@CPF", cliente.CPF);
            dataBase.AdicionarParametros("@DtNascimento", cliente.DtNascimento);
            dataBase.AdicionarParametros("@Telefone", cliente.Telefone);
            dataBase.AdicionarParametros("@Email", cliente.Email);
            
            dataBase.AdicionarParametros("@Cidade", cliente.Cidade);
            dataBase.AdicionarParametros("@Estado", cliente.Estado);
            dataBase.AdicionarParametros("@CEP", cliente.CEP);
            dataBase.AdicionarParametros("@DataCadastro", cliente.DataCadastro);

            dataBase.ExecutarManipulacao(CommandType.Text, queryInserir);
            return Convert.ToInt32(dataBase.ExecutarConsultaScalar(CommandType.Text, "SELECT @@IDENTITY"));
        }

        public int AlterarCliente(Cliente cliente) {
            string queryAlterar =
                @"UPDATE Clientes SET 
                Nome = @Nome, CPF = @CPF, DtNascimento = @DtNascimento, Telefone = @Telefone, 
                Email = @Email,Cidade = @Cidade, Estado = @Estado, CEP = @CEP
                WHERE IdCliente = @IdCliente";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@IdCliente", cliente.IdCliente);
            dataBase.AdicionarParametros("@Nome", cliente.Nome);
            dataBase.AdicionarParametros("@CPF", cliente.CPF);
            dataBase.AdicionarParametros("@DtNascimento", cliente.DtNascimento);
            dataBase.AdicionarParametros("@Telefone", cliente.Telefone);
            dataBase.AdicionarParametros("@Email", cliente.Email);
            
            dataBase.AdicionarParametros("@Cidade", cliente.Cidade);
            dataBase.AdicionarParametros("@Estado", cliente.Estado);
            dataBase.AdicionarParametros("@CEP", cliente.CEP);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryAlterar);
        }

        public int ApagarCliente(int idCliente) {
            string queryApagar =
                @"DELETE FROM Clientes WHERE IdCliente = @IdCliente";

            dataBase.LimparParametros();
            dataBase.AdicionarParametros("@IdCliente", idCliente);

            return dataBase.ExecutarManipulacao(CommandType.Text, queryApagar);
        }

      
    }
}
