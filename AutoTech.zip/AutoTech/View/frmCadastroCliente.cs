﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace AutoTech.View {
    public partial class frmCadastroCliente : Form {
        public frmCadastroCliente() {
            InitializeComponent();
            cbEstado.SelectedIndexChanged += new EventHandler(cbEstado_SelectedIndexChanged);
            CarregarEstadosAsync();
        }

        private async void CarregarEstadosAsync() {
            using (var client = new HttpClient()) {
                var response = await client.GetStringAsync("https://servicodados.ibge.gov.br/api/v1/localidades/estados");
                var estados = JsonConvert.DeserializeObject<List<dynamic>>(response);

                cbEstado.DataSource = estados;
                cbEstado.DisplayMember = "nome";
                cbEstado.ValueMember = "sigla";
            }
        }

        private async void CarregarCidadesAsync(string uf) {
            using (var client = new HttpClient()) {
                var response = await client.GetStringAsync($"https://servicodados.ibge.gov.br/api/v1/localidades/estados/{uf}/municipios");
                var cidades = JsonConvert.DeserializeObject<List<dynamic>>(response);

                cbCidade.DataSource = cidades;
                cbCidade.DisplayMember = "nome";
                cbCidade.ValueMember = "id"; // Ou "nome", dependendo de como você quer armazenar na classe Cliente
            }
        }

        private void cbEstado_SelectedIndexChanged(object sender, EventArgs e) {
            if (cbEstado.SelectedValue != null) {
                string uf = cbEstado.SelectedValue.ToString();
                CarregarCidadesAsync(uf);
            }
        }

        private void textCPF_MaskInputRejected(object sender, MaskInputRejectedEventArgs e) {
            // Você pode adicionar alguma lógica aqui se precisar lidar com entradas inválidas
        }

        // Este método será chamado quando o usuário pressionar uma tecla no campo de CPF
        private void textCPF_KeyPress(object sender, KeyPressEventArgs e) {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Return) {
                string cpf = textCPF.Text;
                bool valido = ValidarCPF(cpf);
                MessageBox.Show(valido ? "CPF válido" : "CPF inválido");
            }
        }

        public static bool ValidarCPF(string cpf) {
            cpf = cpf.Trim();
            cpf = cpf.Replace(".", "").Replace("-", "");

            if (cpf.Length != 11)
                return false;

            for (int j = 0; j < 10; j++)
                if (j.ToString().PadLeft(11, char.Parse(j.ToString())) == cpf)
                    return false;

            int[] multiplicadores1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicadores2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            string tempCpf = cpf.Substring(0, 9);
            int soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicadores1[i];

            int resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            string digito = resto.ToString();
            tempCpf = tempCpf + digito;
            soma = 0;

            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicadores2[i];

            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cpf.EndsWith(digito);
        }


    }
}
    

